using Verse;

namespace BiomesCore.DefModExtensions
{
	public class RockNoiseConfig : DefModExtension
	{
		public float frequency = 0.005f;
		public float offset = 0f;
	}
}