﻿using Verse;

namespace BiomesCore
{
    public class ModExtension_ReleaseGasCloud : DefModExtension
    {
        public GasType gasType = GasType.ToxGas; // BlindSmoke, ToxGas, RotStink, Unused.
        public float amountOfGasFloat = 1f;
    }
}
