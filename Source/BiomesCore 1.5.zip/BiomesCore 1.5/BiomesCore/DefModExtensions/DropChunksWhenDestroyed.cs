using Verse;

namespace BiomesCore.DefModExtensions
{
	public class DropChunksWhenDestroyed : DefModExtension
	{
		public IntRange chunkCountRange = IntRange.one;
	}
}