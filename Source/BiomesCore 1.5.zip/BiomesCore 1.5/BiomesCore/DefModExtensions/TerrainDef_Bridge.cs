﻿using Verse;

namespace BiomesCore.DefModExtensions
{
    public class TerrainDef_Bridge : DefModExtension
    {
        public string loopTexPath = null;
        public string rightTexPath = null;
    }
}
