﻿using RimWorld;
using Verse;

namespace BiomesCore.DefModExtensions
{
    public class PlantHarvestMemoryExtension : DefModExtension
    {
        public ThoughtDef memory;
    }
}