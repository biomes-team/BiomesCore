﻿using Verse;

namespace BiomesCore.DefModExtensions
{
    public class CompetitionHunterModExtension : DefModExtension
    {
        public bool maleEnabled = false;
        public bool femaleEnabled = false;
    }
}