﻿using System.Collections.Generic;
using Verse;

namespace BiomesCore.DefModExtensions
{
    public class PreferenceHunterModExtension : DefModExtension
    {
        public List<ThingDef> huntingPrefs;
    }
}