using RimWorld;

namespace BiomesCore.DefOfs
{
	[DefOf]
	public class StatCategories
	{
		public static StatCategoryDef BC_AnimalCommonality;
		public static StatCategoryDef BC_BiomeCommonality;
	}
}