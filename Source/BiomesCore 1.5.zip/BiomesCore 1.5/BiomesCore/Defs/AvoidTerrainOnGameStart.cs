using System.Collections.Generic;
using Verse;

namespace BiomesCore.Defs
{
	public class AvoidTerrainOnGameStartDef : Def
	{
		public List<TerrainDef> terrains = new List<TerrainDef>();
	}
}